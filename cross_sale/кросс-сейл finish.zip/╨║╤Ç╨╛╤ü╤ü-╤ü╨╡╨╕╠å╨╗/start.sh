#!/bin/bash
/usr/bin/python3 -m venv cross_sale
source cross_sale/bin/activate